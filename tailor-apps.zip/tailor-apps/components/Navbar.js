'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import Logo from './Logo';
import { NAV_LINKS } from '@/lib/site';

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close the mobile menu whenever the route changes.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header
      className={`sticky top-0 z-50 border-b transition-all duration-500 ${
        scrolled
          ? 'border-white/10 bg-ink-950/80 backdrop-blur-xl'
          : 'border-transparent bg-transparent'
      }`}
    >
      <nav className="container-x flex h-20 items-center justify-between" aria-label="Main navigation">
        <Link href="/" aria-label="Tailor Apps home" className="rounded-lg">
          <Logo />
        </Link>

        <ul className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => {
            const active = pathname === link.href;
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={active ? 'page' : undefined}
                  className={`relative block rounded-lg px-4 py-2 text-sm font-medium transition-colors duration-300 ${
                    active ? 'text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute inset-x-4 -bottom-px h-px bg-gradient-to-r from-neon-cyan to-neon-violet" />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>

        <Link href="/get-started" className="btn-primary hidden !px-5 !py-2.5 text-sm md:inline-flex">
          Get Started
        </Link>

        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="glass flex h-11 w-11 items-center justify-center md:hidden"
        >
          <span className="flex flex-col gap-[5px]">
            <span
              className={`block h-0.5 w-5 bg-white transition-transform duration-300 ${
                open ? 'translate-y-[7px] rotate-45' : ''
              }`}
            />
            <span className={`block h-0.5 w-5 bg-white transition-opacity duration-300 ${open ? 'opacity-0' : ''}`} />
            <span
              className={`block h-0.5 w-5 bg-white transition-transform duration-300 ${
                open ? '-translate-y-[7px] -rotate-45' : ''
              }`}
            />
          </span>
        </button>
      </nav>

      <div
        id="mobile-menu"
        className={`grid transition-all duration-500 ease-out md:hidden ${
          open ? 'grid-rows-[1fr] opacity-100' : 'invisible grid-rows-[0fr] opacity-0'
        }`}
      >
        <div className="overflow-hidden">
          <ul className="container-x flex flex-col gap-1 border-t border-white/10 bg-ink-950/95 pb-6 pt-3 backdrop-blur-xl">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className={`block rounded-lg px-4 py-3 text-base font-medium ${
                    pathname === link.href ? 'bg-white/5 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            ))}
            <li className="pt-3">
              <Link href="/get-started" className="btn-primary w-full">
                Get Started
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}
