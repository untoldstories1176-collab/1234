export function LogoMark({ className = 'h-9 w-9' }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="tailor-mark-gradient" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#22d3ee" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="12" fill="url(#tailor-mark-gradient)" />
      {/* Stylised "T" built from a crossbar and stem */}
      <path d="M13 16h22v5h-8.5v11h-5V21H13z" fill="#05070d" />
      {/* Precision stitch point */}
      <circle cx="36" cy="34" r="2.5" fill="#05070d" />
    </svg>
  );
}

export default function Logo({ large = false, className = '' }) {
  if (large) {
    return (
      <span className={`inline-flex items-center gap-4 ${className}`}>
        <LogoMark className="h-16 w-16 sm:h-20 sm:w-20" />
        <span className="font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
          Tailor <span className="text-gradient">Apps</span>
        </span>
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <LogoMark />
      <span className="font-display text-lg font-semibold tracking-tight text-white">
        Tailor <span className="text-gradient">Apps</span>
      </span>
    </span>
  );
}
