import Link from 'next/link';
import Logo from './Logo';
import { NAV_LINKS, SITE } from '@/lib/site';

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-ink-900/60">
      <div className="container-x grid gap-12 py-16 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-slate-400">{SITE.description}</p>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-white">Explore</h3>
          <ul className="mt-5 space-y-3">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="text-sm text-slate-400 transition-colors hover:text-neon-cyan">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-white">Contact</h3>
          <ul className="mt-5 space-y-3 text-sm text-slate-400">
            <li>
              <a href={`mailto:${SITE.email}`} className="break-all transition-colors hover:text-neon-cyan">
                {SITE.email}
              </a>
            </li>
            <li>
              <a href={`tel:${SITE.phoneHref}`} className="transition-colors hover:text-neon-cyan">
                {SITE.phoneDisplay}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="container-x flex flex-col gap-2 py-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Tailor Apps. All rights reserved.</p>
          <p>{SITE.tagline}</p>
        </div>
      </div>
    </footer>
  );
}
