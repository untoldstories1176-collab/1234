'use client';

import { useState } from 'react';
import { APPS, SITE } from '@/lib/site';

const TOPICS = ['Billing', 'Downloads', 'App usage', 'Feature request', 'Feedback', 'Something else'];
const EMPTY = { name: '', email: '', topic: '', app: '', message: '' };

const fieldBase =
  'w-full rounded-xl border bg-ink-900/70 px-4 py-3 text-white placeholder:text-slate-500 outline-none transition-all duration-300 focus:ring-2';
const fieldOk = 'border-white/10 focus:border-neon-cyan focus:ring-neon-cyan/20';
const fieldError = 'border-rose-500/60 focus:border-rose-400 focus:ring-rose-500/20';

function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Please enter your name.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errors.email = 'Enter a valid email address.';
  if (!form.topic) errors.topic = 'Please choose a topic.';
  if (form.message.trim().length < 10) errors.message = 'Message should be at least 10 characters.';
  return errors;
}

export default function ContactForm() {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => {
      if (!prev[name]) return prev;
      const next = { ...prev };
      delete next[name];
      return next;
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    const subject = encodeURIComponent(`[${form.topic}] ${form.app || 'General'} · from ${form.name.trim()}`);
    const body = encodeURIComponent(
      `Name: ${form.name.trim()}\nEmail: ${form.email.trim()}\nApp: ${form.app || 'Not specified'}\nTopic: ${form.topic}\n\n${form.message.trim()}`
    );

    // No backend needed: hand the message to the visitor's email app, addressed to our support inbox.
    window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`;
    setSent(true);
    setForm(EMPTY);
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="glass space-y-6 p-6 sm:p-8" aria-label="Contact form">
      {sent && (
        <div role="status" className="rounded-xl border border-neon-lime/30 bg-neon-lime/10 px-4 py-3 text-sm text-neon-lime">
          Thanks! Your email app should open with your message ready to send. If it does not, email us directly at{' '}
          <span className="font-semibold">{SITE.email}</span>.
        </div>
      )}

      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="mb-2 block text-sm font-medium text-slate-300">
            Full name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            value={form.name}
            onChange={handleChange}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? 'name-error' : undefined}
            placeholder="Your name"
            className={`${fieldBase} ${errors.name ? fieldError : fieldOk}`}
          />
          {errors.name && (
            <p id="name-error" className="mt-2 text-xs text-rose-400">
              {errors.name}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="mb-2 block text-sm font-medium text-slate-300">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={handleChange}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'email-error' : undefined}
            placeholder="you@example.com"
            className={`${fieldBase} ${errors.email ? fieldError : fieldOk}`}
          />
          {errors.email && (
            <p id="email-error" className="mt-2 text-xs text-rose-400">
              {errors.email}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="topic" className="mb-2 block text-sm font-medium text-slate-300">
            Topic
          </label>
          <select
            id="topic"
            name="topic"
            value={form.topic}
            onChange={handleChange}
            aria-invalid={Boolean(errors.topic)}
            aria-describedby={errors.topic ? 'topic-error' : undefined}
            className={`${fieldBase} ${errors.topic ? fieldError : fieldOk} appearance-none`}
          >
            <option value="" disabled>
              Choose a topic
            </option>
            {TOPICS.map((topic) => (
              <option key={topic} value={topic}>
                {topic}
              </option>
            ))}
          </select>
          {errors.topic && (
            <p id="topic-error" className="mt-2 text-xs text-rose-400">
              {errors.topic}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="app" className="mb-2 block text-sm font-medium text-slate-300">
            App <span className="text-slate-500">(optional)</span>
          </label>
          <select
            id="app"
            name="app"
            value={form.app}
            onChange={handleChange}
            className={`${fieldBase} ${fieldOk} appearance-none`}
          >
            <option value="">General / not sure</option>
            {APPS.map((app) => (
              <option key={app.id} value={app.name}>
                {app.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="message" className="mb-2 block text-sm font-medium text-slate-300">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          rows={5}
          value={form.message}
          onChange={handleChange}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? 'message-error' : undefined}
          placeholder="Tell us how we can help..."
          className={`${fieldBase} ${errors.message ? fieldError : fieldOk} resize-y`}
        />
        {errors.message && (
          <p id="message-error" className="mt-2 text-xs text-rose-400">
            {errors.message}
          </p>
        )}
      </div>

      <button type="submit" className="btn-primary w-full sm:w-auto">
        Send message
      </button>
    </form>
  );
}
