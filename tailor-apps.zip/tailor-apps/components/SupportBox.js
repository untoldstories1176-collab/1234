import { SITE } from '@/lib/site';

export default function SupportBox() {
  return (
    <div className="glass relative h-full overflow-hidden p-8">
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-neon-violet/25 blur-[70px]" aria-hidden="true" />

      <div className="relative">
        <span className="eyebrow">Direct support</span>
        <h2 className="mt-5 text-2xl font-bold">Talk to our team</h2>
        <p className="mt-3 text-sm leading-relaxed text-slate-400">
          Real people, real answers. Reach us by email or phone with any billing, download or usage question.
        </p>

        <ul className="mt-8 space-y-6">
          <li className="rounded-2xl border border-white/10 bg-ink-950/50 p-5 transition-colors duration-300 hover:border-neon-cyan/40">
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-500">Email</p>
            <a
              href={`mailto:${SITE.email}`}
              className="mt-2 block break-all text-lg font-semibold text-white transition-colors hover:text-neon-cyan"
            >
              {SITE.email}
            </a>
          </li>
          <li className="rounded-2xl border border-white/10 bg-ink-950/50 p-5 transition-colors duration-300 hover:border-neon-cyan/40">
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-500">Contact number</p>
            <a
              href={`tel:${SITE.phoneHref}`}
              className="mt-2 block text-lg font-semibold text-white transition-colors hover:text-neon-cyan"
            >
              {SITE.phoneDisplay}
            </a>
          </li>
        </ul>

        <p className="mt-6 text-xs text-slate-500">We aim to reply within one business day.</p>
      </div>
    </div>
  );
}
