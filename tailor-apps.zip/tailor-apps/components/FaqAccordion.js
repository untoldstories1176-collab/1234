'use client';

import { useState } from 'react';

export default function FaqAccordion({ groups }) {
  const [openId, setOpenId] = useState(null);

  return (
    <div className="space-y-12">
      {groups.map((group) => (
        <section key={group.id} aria-labelledby={`faq-${group.id}`}>
          <h3
            id={`faq-${group.id}`}
            className="mb-5 text-sm font-semibold uppercase tracking-[0.2em] text-neon-cyan"
          >
            {group.title}
          </h3>

          <div className="space-y-3">
            {group.items.map((item, index) => {
              const id = `${group.id}-${index}`;
              const open = openId === id;

              return (
                <div
                  key={id}
                  className={`glass overflow-hidden transition-colors duration-500 ${
                    open ? 'border-neon-cyan/40' : 'hover:border-white/20'
                  }`}
                >
                  <button
                    type="button"
                    id={`btn-${id}`}
                    aria-expanded={open}
                    aria-controls={`panel-${id}`}
                    onClick={() => setOpenId(open ? null : id)}
                    className="flex w-full items-center justify-between gap-6 px-6 py-5 text-left"
                  >
                    <span className="font-medium text-white">{item.q}</span>
                    <span
                      aria-hidden="true"
                      className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-lg leading-none transition-all duration-500 ${
                        open
                          ? 'rotate-45 border-neon-cyan/50 bg-neon-cyan/10 text-neon-cyan'
                          : 'border-white/15 text-slate-300'
                      }`}
                    >
                      +
                    </span>
                  </button>

                  <div
                    id={`panel-${id}`}
                    role="region"
                    aria-labelledby={`btn-${id}`}
                    className={`grid transition-[grid-template-rows,opacity] duration-500 ease-out ${
                      open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="px-6 pb-6 leading-relaxed text-slate-400">{item.a}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
