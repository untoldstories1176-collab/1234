const BARS = Array.from({ length: 18 }, (_, i) => i);

export default function PhoneMockup() {
  return (
    <div className="relative mx-auto w-full max-w-[320px] animate-float">
      <div className="absolute -inset-12 rounded-full bg-neon-cyan/20 blur-[90px] animate-glow" aria-hidden="true" />

      <div className="relative rounded-[2.5rem] border border-white/15 bg-ink-900/90 p-3 shadow-2xl shadow-black/60 backdrop-blur-xl">
        <div className="flex min-h-[520px] flex-col rounded-[2rem] bg-gradient-to-b from-ink-800 to-ink-950 p-5">
          <div className="mx-auto h-1.5 w-20 rounded-full bg-white/10" />

          <div className="mt-8 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">Smart Alert</span>
            <span className="h-2 w-2 animate-pulse rounded-full bg-neon-lime" />
          </div>

          <div className="glass mt-6 p-5">
            <p className="text-xs font-medium text-neon-cyan">Next alert</p>
            <p className="mt-1 font-display text-3xl font-semibold text-white">Asr</p>
            <p className="text-sm text-slate-400">Voice alert · 10 min before</p>

            <div className="mt-6 flex h-16 items-center gap-1" aria-hidden="true">
              {BARS.map((i) => (
                <span
                  key={i}
                  className="block w-1.5 origin-center rounded-full bg-gradient-to-t from-neon-cyan to-neon-violet animate-wave"
                  style={{
                    height: `${30 + ((i * 37) % 70)}%`,
                    animationDelay: `${i * 80}ms`,
                  }}
                />
              ))}
            </div>
          </div>

          <ul className="mt-6 space-y-3">
            {[
              ['Voice search', 'Hands-free'],
              ['Alarm sound', 'Chime'],
              ['Theme', 'Aurora'],
            ].map(([label, value]) => (
              <li
                key={label}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm"
              >
                <span className="text-slate-300">{label}</span>
                <span className="text-neon-cyan">{value}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
