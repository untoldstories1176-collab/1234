import Link from 'next/link';

export default function AppCard({ app, featured = false, showDetailsLink = false }) {
  const isFlagship = featured || app.flagship;

  return (
    <article
      className={`glass group relative flex h-full flex-col p-6 transition-all duration-500 hover:-translate-y-1 hover:border-neon-cyan/40 hover:shadow-glow ${
        isFlagship ? 'border-neon-cyan/35 shadow-glow ring-1 ring-neon-cyan/25' : ''
      }`}
    >
      {isFlagship && (
        <span className="absolute right-5 top-5 rounded-full bg-neon-cyan/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-neon-cyan">
          Flagship
        </span>
      )}

      <div
        className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${app.iconClass} font-display text-lg font-bold text-ink-950 shadow-lg transition-transform duration-500 group-hover:scale-105`}
        aria-hidden="true"
      >
        {app.initial}
      </div>

      <h3 className="mt-6 text-xl font-semibold text-white">{app.name}</h3>
      <p className="mt-1 text-sm font-medium text-neon-cyan/90">{app.tagline}</p>
      <p className="mt-4 flex-1 text-sm leading-relaxed text-slate-400">{app.summary}</p>

      <div className="mt-6 flex items-center justify-between gap-3 border-t border-white/10 pt-5">
        <span className="text-xs font-medium uppercase tracking-widest text-slate-500">Paid · Ad-free</span>
        {showDetailsLink ? (
          <Link href="/get-started" className="text-sm font-semibold text-white transition-colors hover:text-neon-cyan">
            Details →
          </Link>
        ) : (
          <a
            href={app.playUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-semibold text-white transition-colors hover:text-neon-cyan"
          >
            Get app →
          </a>
        )}
      </div>
    </article>
  );
}
