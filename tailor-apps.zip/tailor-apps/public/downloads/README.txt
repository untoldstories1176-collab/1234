Place the Smart Alert trial build here as:

    smart-alert-trial.apk

The Get Started page links to /downloads/smart-alert-trial.apk.
