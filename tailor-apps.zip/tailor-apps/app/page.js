import Link from 'next/link';
import Reveal from '@/components/Reveal';
import AppCard from '@/components/AppCard';
import PhoneMockup from '@/components/PhoneMockup';
import { APPS, SMART_ALERT_FEATURES, WHY_US, FREE_VS_PAID } from '@/lib/site';

export const metadata = {
  title: 'Premium Paid Mobile Apps',
  description:
    'Four premium paid mobile apps from Tailor Apps. Ad-free, privacy-first and updated for life. Discover Smart Alert, our flagship app.',
};

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0" aria-hidden="true">
          <div className="absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-neon-cyan/15 blur-[130px] animate-glow" />
          <div className="absolute right-[-10%] top-40 h-[420px] w-[420px] rounded-full bg-neon-violet/20 blur-[120px] animate-glow" style={{ animationDelay: '2s' }} />
        </div>

        <div className="container-x relative grid items-center gap-16 py-20 sm:py-28 lg:grid-cols-2 lg:py-36">
          <div>
            <span className="eyebrow animate-slide-up">Four premium paid apps</span>

            <h1
              className="mt-6 text-5xl font-bold leading-[1.05] sm:text-6xl lg:text-7xl animate-slide-up"
              style={{ animationDelay: '120ms' }}
            >
              Premium apps.
              <br />
              <span className="text-gradient">Zero ads.</span> Built to last.
            </h1>

            <p
              className="mt-6 max-w-xl text-lg leading-relaxed text-slate-400 animate-slide-up"
              style={{ animationDelay: '240ms' }}
            >
              Tailor Apps crafts a portfolio of four paid mobile apps with precision engineering. No ads, no tracking
              clutter, no hidden costs. Just software that does its job well.
            </p>

            <div className="mt-10 flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: '360ms' }}>
              <Link href="/get-started" className="btn-primary">
                Get Started
                <span aria-hidden="true">→</span>
              </Link>
              <Link href="#smart-alert" className="btn-ghost">
                Explore Smart Alert
              </Link>
            </div>

            <dl className="mt-14 grid max-w-md grid-cols-3 gap-4 sm:gap-6 animate-slide-up" style={{ animationDelay: '480ms' }}>
              <div>
                <dt className="text-xs uppercase tracking-widest text-slate-500">Apps</dt>
                <dd className="mt-1 font-display text-2xl font-semibold text-white sm:text-3xl">4</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-widest text-slate-500">Ads</dt>
                <dd className="mt-1 font-display text-2xl font-semibold text-white sm:text-3xl">0</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-widest text-slate-500">Updates</dt>
                <dd className="mt-1 font-display text-2xl font-semibold text-white sm:text-3xl">Lifetime</dd>
              </div>
            </dl>
          </div>

          <div className="animate-fade-in" style={{ animationDelay: '300ms' }}>
            <PhoneMockup />
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section aria-label="Highlights" className="relative border-y border-white/10 bg-ink-900/40">
        <div className="container-x grid grid-cols-2 gap-6 py-8 md:grid-cols-4">
          {['Available on Google Play', '100% ad-free', 'Privacy-first design', 'Lifetime updates'].map((item) => (
            <div key={item} className="flex items-center gap-3 text-sm font-medium text-slate-300">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-neon-lime/15 text-xs text-neon-lime" aria-hidden="true">
                ✓
              </span>
              {item}
            </div>
          ))}
        </div>
      </section>

      {/* APP GRID */}
      <section className="section relative" id="apps">
        <div className="container-x">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="eyebrow">Our portfolio</span>
            <h2 className="mt-5 text-3xl font-bold sm:text-4xl">Four apps, one standard of quality</h2>
            <p className="mt-4 text-slate-400">
              Every Tailor Apps product is designed, built and maintained with the same care. Pick the one that fits
              your life, or get the whole set.
            </p>
          </Reveal>

          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {APPS.map((app, index) => (
              <Reveal key={app.id} delay={index * 120} className="h-full">
                <AppCard app={app} showDetailsLink />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* SMART ALERT SPOTLIGHT */}
      <section className="section relative" id="smart-alert">
        <div className="pointer-events-none absolute left-0 top-1/3 h-[420px] w-[420px] rounded-full bg-neon-violet/15 blur-[120px]" aria-hidden="true" />

        <div className="container-x relative">
          <Reveal className="grid items-end gap-6 md:grid-cols-2">
            <div>
              <span className="eyebrow">Flagship app</span>
              <h2 className="mt-5 text-4xl font-bold sm:text-5xl">
                Meet <span className="text-gradient">Smart Alert</span>
              </h2>
            </div>
            <p className="text-lg leading-relaxed text-slate-400 md:justify-self-end md:max-w-md">
              Our flagship app combines prayer-time voice alerts, hands-free search and intelligent reminders in a single
              beautifully customizable experience.
            </p>
          </Reveal>

          <div className="mt-16 grid gap-6 md:grid-cols-2">
            {SMART_ALERT_FEATURES.map((feature, index) => (
              <Reveal key={feature.title} delay={index * 120}>
                <div className="glass group h-full p-8 transition-all duration-500 hover:-translate-y-1 hover:border-neon-cyan/40 hover:shadow-glow">
                  <div className="flex items-center gap-4">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-neon-cyan/30 bg-neon-cyan/10 font-display text-sm font-bold text-neon-cyan">
                      0{index + 1}
                    </span>
                    <h3 className="text-xl font-semibold text-white">{feature.title}</h3>
                  </div>
                  <p className="mt-5 leading-relaxed text-slate-400">{feature.text}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-12 flex flex-wrap justify-center gap-4">
            <Link href="/get-started" className="btn-primary">
              Download Smart Alert
              <span aria-hidden="true">→</span>
            </Link>
            <Link href="/get-started#trial" className="btn-ghost">
              Try the trial APK
            </Link>
          </Reveal>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section relative" id="why-us">
        <div className="container-x">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="eyebrow">Why Tailor Apps</span>
            <h2 className="mt-5 text-3xl font-bold sm:text-4xl">Paid apps, done properly</h2>
            <p className="mt-4 text-slate-400">
              Free apps often cost you in attention and privacy. Our paid apps are built around the opposite promise.
            </p>
          </Reveal>

          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {WHY_US.map((item, index) => (
              <Reveal key={item.title} delay={index * 100} className="h-full">
                <div className="glass h-full p-7 transition-all duration-500 hover:-translate-y-1 hover:border-neon-violet/40">
                  <span className="font-display text-sm font-bold text-neon-violet">{item.icon}</span>
                  <h3 className="mt-4 text-lg font-semibold text-white">{item.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">{item.text}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-16">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="glass p-8">
                <p className="text-sm font-semibold uppercase tracking-widest text-slate-500">Free alternatives</p>
                <ul className="mt-6 space-y-4">
                  {FREE_VS_PAID.free.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-slate-400">
                      <span className="mt-1 text-rose-400" aria-hidden="true">✕</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="glass border-neon-cyan/30 p-8 shadow-glow">
                <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">Tailor Apps</p>
                <ul className="mt-6 space-y-4">
                  {FREE_VS_PAID.paid.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-slate-200">
                      <span className="mt-1 text-neon-lime" aria-hidden="true">✓</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CTA BAND */}
      <section className="section pt-0">
        <div className="container-x">
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-ink-800 to-ink-900 px-6 py-16 text-center sm:px-16">
              <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-neon-cyan/20 blur-[90px]" aria-hidden="true" />
              <div className="pointer-events-none absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-neon-violet/25 blur-[90px]" aria-hidden="true" />
              <h2 className="relative text-3xl font-bold sm:text-4xl">Ready for an app that just works?</h2>
              <p className="relative mx-auto mt-4 max-w-xl text-slate-400">
                Set up in minutes, enjoy it without ads, and receive every update that follows.
              </p>
              <div className="relative mt-10 flex flex-wrap justify-center gap-4">
                <Link href="/get-started" className="btn-primary">
                  Get Started
                </Link>
                <Link href="/help" className="btn-ghost">
                  Talk to support
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
