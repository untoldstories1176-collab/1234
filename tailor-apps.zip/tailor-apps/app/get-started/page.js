import Link from 'next/link';
import Reveal from '@/components/Reveal';
import AppCard from '@/components/AppCard';
import { APPS, ONBOARDING_STEPS, SMART_ALERT_FEATURES, TRIAL } from '@/lib/site';

export const metadata = {
  title: 'Get Started',
  description:
    'Get started with Tailor Apps. Follow the quick onboarding guide, download Smart Alert from Google Play and explore our full app portfolio.',
};

export default function GetStartedPage() {
  const flagship = APPS.find((app) => app.flagship);
  const others = APPS.filter((app) => !app.flagship);

  return (
    <>
      {/* PAGE HEADER */}
      <section className="relative overflow-hidden grid-bg">
        <div className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[520px] -translate-x-1/2 rounded-full bg-neon-cyan/10 blur-[120px] animate-glow" aria-hidden="true" />
        <div className="container-x relative py-20 text-center sm:py-28">
          <span className="eyebrow animate-slide-up">Get started</span>
          <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-bold sm:text-6xl animate-slide-up" style={{ animationDelay: '120ms' }}>
            Up and running in <span className="text-gradient">three minutes</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400 animate-slide-up" style={{ animationDelay: '240ms' }}>
            New to Tailor Apps? This short guide walks you through installing, setting up and personalizing your first app.
          </p>
        </div>
      </section>

      {/* ONBOARDING GUIDE */}
      <section className="section pt-12">
        <div className="container-x">
          <Reveal className="mb-12 flex items-end justify-between gap-6">
            <div>
              <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">Onboarding guide</p>
              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Four steps to your first alert</h2>
            </div>
          </Reveal>

          <ol className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {ONBOARDING_STEPS.map((step, index) => (
              <Reveal as="li" key={step.title} delay={index * 120} className="relative h-full">
                <div className="glass h-full p-7">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-neon-cyan to-neon-violet font-display text-sm font-bold text-ink-950">
                    {index + 1}
                  </span>
                  <h3 className="mt-6 text-lg font-semibold text-white">{step.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">{step.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* FLAGSHIP CARD */}
      <section className="section pt-0" id="smart-alert">
        <div className="container-x">
          <Reveal>
            <div className="glass relative overflow-hidden border-neon-cyan/30 p-8 shadow-glow sm:p-12">
              <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-neon-violet/20 blur-[100px]" aria-hidden="true" />

              <div className="relative grid items-center gap-12 lg:grid-cols-2">
                <div>
                  <span className="eyebrow">Flagship app</span>
                  <div className="mt-6 flex items-center gap-5">
                    <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-neon-cyan to-neon-violet font-display text-2xl font-bold text-ink-950 shadow-glow">
                      SA
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold sm:text-4xl">{flagship.name}</h2>
                      <p className="mt-1 text-neon-cyan/90">{flagship.tagline}</p>
                    </div>
                  </div>
                  <p className="mt-6 max-w-lg leading-relaxed text-slate-400">{flagship.summary}</p>

                  <a
                    href={flagship.playUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary mt-10 w-full sm:w-auto !px-8 !py-4 text-base"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true" fill="currentColor">
                      <path d="M3.6 1.8 13.4 12 3.6 22.2c-.3-.2-.6-.6-.6-1.2V3c0-.6.3-1 .6-1.2zm11.5 11.9 2.6 2.7-11.8 6.7 9.2-9.4zm0-1.4L6 4.4l11.8 6.7 2.6-2.7zM17.8 9.5l3 1.7c.8.5.8 1.4 0 1.9l-3 1.7-2.8-2.7z" />
                    </svg>
                    Download on Google Play
                  </a>
                  <p className="mt-4 text-xs text-slate-500">Opens the official Google Play listing in a new tab.</p>
                </div>

                <ul className="grid gap-4">
                  {SMART_ALERT_FEATURES.map((feature) => (
                    <li key={feature.title} className="rounded-2xl border border-white/10 bg-ink-950/50 p-5">
                      <p className="font-semibold text-white">{feature.title}</p>
                      <p className="mt-1 text-sm leading-relaxed text-slate-400">{feature.text}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* TRIAL APK */}
      <section className="section pt-0" id="trial">
        <div className="container-x">
          <Reveal className="mb-12 max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-lime">Try before you buy</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Download the trial APK</h2>
            <p className="mt-4 text-slate-400">{TRIAL.note}</p>
          </Reveal>

          <div className="grid gap-6 lg:grid-cols-5">
            <Reveal className="lg:col-span-2">
              <div className="glass relative flex h-full flex-col overflow-hidden p-8">
                <div className="pointer-events-none absolute -left-16 -bottom-16 h-56 w-56 rounded-full bg-neon-lime/15 blur-[80px]" aria-hidden="true" />
                <div className="relative">
                  <span className="eyebrow !border-neon-lime/30 !bg-neon-lime/5 !text-neon-lime">Android APK</span>
                  <h3 className="mt-5 text-2xl font-bold text-white">{TRIAL.label}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">
                    A direct-download build of our flagship app for hands-on testing.
                  </p>

                  <a
                    href={TRIAL.href}
                    download={TRIAL.fileName}
                    className="btn-primary mt-8 w-full !px-8 !py-4 text-base"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 3v12m0 0-5-5m5 5 5-5M4 19h16" />
                    </svg>
                    Download trial APK
                  </a>

                  <div className="mt-6 rounded-xl border border-amber-400/25 bg-amber-400/5 p-4 text-xs leading-relaxed text-amber-200/90">
                    <span className="font-semibold text-amber-300">Heads up: </span>
                    {TRIAL.safety}
                  </div>
                </div>
              </div>
            </Reveal>

            <ol className="grid gap-4 sm:grid-cols-2 lg:col-span-3">
              {TRIAL.steps.map((step, index) => (
                <Reveal as="li" key={step.title} delay={index * 100} className="h-full">
                  <div className="glass h-full p-6 transition-all duration-500 hover:-translate-y-1 hover:border-neon-lime/40">
                    <span className="font-display text-sm font-bold text-neon-lime">Step {index + 1}</span>
                    <h3 className="mt-3 text-lg font-semibold text-white">{step.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-400">{step.text}</p>
                  </div>
                </Reveal>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* OTHER APPS */}
      <section className="section pt-0" id="more-apps">
        <div className="container-x">
          <Reveal className="mb-12 max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-violet">More from Tailor Apps</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Three more premium apps</h2>
            <p className="mt-4 text-slate-400">Built on the same principles: ad-free, private and maintained for the long run.</p>
          </Reveal>

          <div className="grid gap-6 md:grid-cols-3">
            {others.map((app, index) => (
              <Reveal key={app.id} delay={index * 120} className="h-full">
                <AppCard app={app} />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-16 text-center">
            <p className="text-slate-400">
              Have questions before you buy?{' '}
              <Link href="/help" className="font-semibold text-neon-cyan underline-offset-4 hover:underline">
                Visit Help &amp; Support
              </Link>
            </p>
          </Reveal>
        </div>
      </section>
    </>
  );
}
