import Reveal from '@/components/Reveal';
import FaqAccordion from '@/components/FaqAccordion';
import ContactForm from '@/components/ContactForm';
import SupportBox from '@/components/SupportBox';
import { FAQ_GROUPS } from '@/lib/faq';

export const metadata = {
  title: 'Help & Support',
  description:
    'Get help with billing, downloads and app usage. Browse the Tailor Apps FAQ, contact our support team or send us feedback.',
};

export default function HelpPage() {
  return (
    <>
      {/* PAGE HEADER */}
      <section className="relative overflow-hidden grid-bg">
        <div className="pointer-events-none absolute left-1/2 top-0 h-[400px] w-[500px] -translate-x-1/2 rounded-full bg-neon-violet/15 blur-[120px] animate-glow" aria-hidden="true" />
        <div className="container-x relative py-20 text-center sm:py-28">
          <span className="eyebrow animate-slide-up">Help &amp; support</span>
          <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-bold sm:text-6xl animate-slide-up" style={{ animationDelay: '120ms' }}>
            How can we <span className="text-gradient">help you?</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400 animate-slide-up" style={{ animationDelay: '240ms' }}>
            Find quick answers below, or reach out directly. We are happy to help.
          </p>
        </div>
      </section>

      {/* SUPPORT + FAQ */}
      <section className="section pt-8">
        <div className="container-x grid gap-10 lg:grid-cols-5 lg:gap-14">
          <Reveal className="lg:col-span-2 lg:sticky lg:top-28 lg:self-start">
            <SupportBox />
          </Reveal>

          <div className="lg:col-span-3">
            <Reveal>
              <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">Frequently asked questions</p>
              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Answers, fast</h2>
              <p className="mt-4 mb-10 text-slate-400">Browse by topic. Tap a question to reveal the answer.</p>
            </Reveal>
            <Reveal delay={150}>
              <FaqAccordion groups={FAQ_GROUPS} />
            </Reveal>
          </div>
        </div>
      </section>

      {/* FEEDBACK FORM */}
      <section className="section pt-0" id="contact">
        <div className="container-x grid gap-10 lg:grid-cols-5 lg:gap-14">
          <Reveal className="lg:col-span-2">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-violet">Feedback &amp; contact</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Send us a message</h2>
            <p className="mt-4 leading-relaxed text-slate-400">
              Report a problem, request a feature or share your thoughts. Every message is read by a real person on the
              Tailor Apps team.
            </p>
          </Reveal>

          <Reveal delay={150} className="lg:col-span-3">
            <ContactForm />
          </Reveal>
        </div>
      </section>
    </>
  );
}
