import Link from 'next/link';
import Reveal from '@/components/Reveal';
import Logo, { LogoMark } from '@/components/Logo';
import { SITE } from '@/lib/site';

export const metadata = {
  title: 'Brand Identity',
  description: 'The Tailor Apps brand: logo, tagline, colour palette, typography and core principles.',
};

const PALETTE = [
  { name: 'Ink', role: 'Background', hex: '#05070D', text: 'text-slate-300' },
  { name: 'Ink 900', role: 'Surface', hex: '#0A0E1A', text: 'text-slate-300' },
  { name: 'Neon Cyan', role: 'Primary accent', hex: '#22D3EE', text: 'text-ink-950' },
  { name: 'Neon Violet', role: 'Secondary accent', hex: '#8B5CF6', text: 'text-white' },
  { name: 'Neon Lime', role: 'Success / status', hex: '#A3E635', text: 'text-ink-950' },
];

const PILLARS = [
  { title: 'Precision', text: 'Every interaction is measured, deliberate and built to feel effortless.' },
  { title: 'Privacy', text: 'Respect for the user comes first. No ad-tracking, no unnecessary data.' },
  { title: 'Premium quality', text: 'We charge for value, so the product has to earn it every single day.' },
  { title: 'Longevity', text: 'Lifetime updates mean our apps keep getting better long after launch.' },
];

export default function BrandPage() {
  return (
    <>
      {/* HERO / BRAND HEADER */}
      <section className="relative overflow-hidden grid-bg">
        <div className="pointer-events-none absolute left-1/2 top-10 h-[460px] w-[620px] -translate-x-1/2 rounded-full bg-neon-cyan/15 blur-[130px] animate-glow" aria-hidden="true" />
        <div className="pointer-events-none absolute right-0 top-40 h-[300px] w-[300px] rounded-full bg-neon-violet/20 blur-[110px] animate-glow" aria-hidden="true" style={{ animationDelay: '2s' }} />

        <div className="container-x relative flex flex-col items-center py-24 text-center sm:py-36">
          <div className="animate-fade-in">
            <Logo large />
          </div>

          <p
            className="mt-10 font-display text-xl font-medium uppercase tracking-[0.35em] text-slate-300 animate-slide-up sm:text-2xl"
            style={{ animationDelay: '200ms' }}
          >
            {SITE.tagline}
          </p>
          <p
            className="mt-6 max-w-2xl text-lg leading-relaxed text-slate-400 animate-slide-up"
            style={{ animationDelay: '320ms' }}
          >
            We craft premium, paid mobile applications with the discipline of a precision engineering firm and the
            polish of a design studio.
          </p>
        </div>
      </section>

      {/* LOGO VARIANTS */}
      <section className="section pt-0">
        <div className="container-x">
          <Reveal className="mb-12 max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">Logo</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">The mark and wordmark</h2>
            <p className="mt-4 text-slate-400">
              A stitched “T” inside a gradient tile, paired with a clean geometric wordmark. The gradient runs from cyan to
              violet, the signature of the brand.
            </p>
          </Reveal>

          <div className="grid gap-6 md:grid-cols-3">
            <Reveal className="md:col-span-3">
              <div className="glass flex min-h-[220px] items-center justify-center p-10">
                <Logo large />
              </div>
            </Reveal>

            <Reveal delay={100}>
              <div className="glass flex h-full min-h-[200px] flex-col items-center justify-center gap-4 p-8">
                <LogoMark className="h-24 w-24" />
                <p className="text-xs uppercase tracking-widest text-slate-500">Mark only</p>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="flex h-full min-h-[200px] flex-col items-center justify-center gap-4 rounded-2xl bg-white p-8">
                <span className="inline-flex items-center gap-2.5">
                  <LogoMark className="h-9 w-9" />
                  <span className="font-display text-lg font-semibold tracking-tight text-ink-950">
                    Tailor <span className="bg-gradient-to-r from-cyan-500 to-violet-600 bg-clip-text text-transparent">Apps</span>
                  </span>
                </span>
                <p className="text-xs uppercase tracking-widest text-slate-500">On light</p>
              </div>
            </Reveal>

            <Reveal delay={300}>
              <div className="glass flex h-full min-h-[200px] flex-col items-center justify-center gap-4 p-8">
                <Logo />
                <p className="text-xs uppercase tracking-widest text-slate-500">Compact on dark</p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* COLOUR PALETTE */}
      <section className="section pt-0">
        <div className="container-x">
          <Reveal className="mb-12 max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-violet">Colour palette</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Dark, sharp and luminous</h2>
          </Reveal>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {PALETTE.map((swatch, index) => (
              <Reveal key={swatch.hex} delay={index * 90} className="h-full">
                <div className="glass h-full overflow-hidden transition-all duration-500 hover:-translate-y-1 hover:shadow-glow">
                  <div
                    className={`flex h-32 items-end p-4 font-display text-sm font-semibold ${swatch.text}`}
                    style={{ backgroundColor: swatch.hex }}
                  >
                    {swatch.hex}
                  </div>
                  <div className="p-4">
                    <p className="font-semibold text-white">{swatch.name}</p>
                    <p className="text-xs text-slate-500">{swatch.role}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* TYPOGRAPHY */}
      <section className="section pt-0">
        <div className="container-x grid gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="glass h-full p-8 sm:p-10">
              <p className="text-xs font-semibold uppercase tracking-widest text-slate-500">Display · Space Grotesk</p>
              <p className="mt-6 font-display text-4xl font-bold text-white">Precision in every pixel</p>
              <p className="mt-4 font-display text-lg text-slate-400">ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789</p>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <div className="glass h-full p-8 sm:p-10">
              <p className="text-xs font-semibold uppercase tracking-widest text-slate-500">Body · Inter</p>
              <p className="mt-6 text-2xl font-medium text-white">Clear, calm and easy to read.</p>
              <p className="mt-4 leading-relaxed text-slate-400">
                Body text favours generous line height and comfortable measure, so every screen, page and message stays
                easy to follow.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* PILLARS */}
      <section className="section pt-0">
        <div className="container-x">
          <Reveal className="mb-12 max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">Brand principles</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Four pillars we build on</h2>
          </Reveal>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {PILLARS.map((pillar, index) => (
              <Reveal key={pillar.title} delay={index * 100} className="h-full">
                <div className="glass h-full p-7 transition-all duration-500 hover:-translate-y-1 hover:border-neon-cyan/40">
                  <h3 className="text-lg font-semibold text-white">{pillar.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">{pillar.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section pt-0">
        <div className="container-x">
          <Reveal className="glass flex flex-col items-center gap-6 p-10 text-center sm:p-14">
            <p className="font-display text-2xl font-semibold text-white sm:text-3xl">
              Premium software, <span className="text-gradient">engineered with precision.</span>
            </p>
            <Link href="/get-started" className="btn-primary">
              Get Started
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
