import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="container-x flex min-h-[70vh] flex-col items-center justify-center py-24 text-center">
      <span className="eyebrow animate-slide-up">404</span>
      <h1 className="mt-6 text-5xl font-bold animate-slide-up" style={{ animationDelay: '120ms' }}>
        Page not found
      </h1>
      <p className="mt-4 max-w-md text-slate-400 animate-slide-up" style={{ animationDelay: '240ms' }}>
        The page you are looking for does not exist or has moved.
      </p>
      <div className="mt-10 flex flex-wrap justify-center gap-4 animate-slide-up" style={{ animationDelay: '360ms' }}>
        <Link href="/" className="btn-primary">
          Back to home
        </Link>
        <Link href="/help" className="btn-ghost">
          Get help
        </Link>
      </div>
    </section>
  );
}
